import{Ad as n,Bd as r,Fd as e,Id as o,zd as t}from"./chunk-6PRZEEKG.js";var s=e({Key:o([n,t]),Value:t}),m=e({Key:o([n,t]),Value:t,IsActive:r});export{s as a,m as b};
