import{f as o,g as a}from"./chunk-2QS7YZBA.js";function c(e,r,i){let t=a(e,i?.in);return isNaN(r)?o(i?.in||e,NaN):(r&&t.setDate(t.getDate()+r),t)}export{c as a};
