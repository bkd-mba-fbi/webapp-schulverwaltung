import{Jc as t,Kc as n,Pc as o,Rc as r}from"./chunk-TTJNYD2F.js";var i=o({Key:r([n,t]),Value:t});export{i as a};
