import{Lc as t,Mc as n,Rc as o,Tc as r}from"./chunk-QCWENUND.js";var i=o({Key:r([n,t]),Value:t});export{i as a};
