import{$c as e,Vc as t,Wc as n,Xc as r,bd as o}from"./chunk-4HLXNFKK.js";var s=e({Key:o([n,t]),Value:t}),m=e({Key:o([n,t]),Value:t,IsActive:r});export{s as a,m as b};
