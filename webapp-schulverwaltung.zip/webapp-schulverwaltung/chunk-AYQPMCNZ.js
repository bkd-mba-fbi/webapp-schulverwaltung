import{Hc as t,Ic as n,Nc as o,Pc as r}from"./chunk-2W7IS4PN.js";var i=o({Key:r([n,t]),Value:t});export{i as a};
