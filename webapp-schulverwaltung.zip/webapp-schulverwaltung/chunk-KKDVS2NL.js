import{Md as t,Nd as n,Od as r,Sd as e,Vd as o}from"./chunk-CHBP6U4G.js";var s=e({Key:o([n,t]),Value:t}),m=e({Key:o([n,t]),Value:t,IsActive:r});export{s as a,m as b};
