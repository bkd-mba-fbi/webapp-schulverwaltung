import{Qc as t,Rc as n,Sc as r,Wc as e,Yc as o}from"./chunk-SJCSLNDG.js";var s=e({Key:o([n,t]),Value:t}),m=e({Key:o([n,t]),Value:t,IsActive:r});export{s as a,m as b};
