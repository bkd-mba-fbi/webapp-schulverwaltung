import{Gc as t,Hc as n,Mc as o,Oc as r}from"./chunk-34ZOBT6Z.js";var i=o({Key:r([n,t]),Value:t});export{i as a};
